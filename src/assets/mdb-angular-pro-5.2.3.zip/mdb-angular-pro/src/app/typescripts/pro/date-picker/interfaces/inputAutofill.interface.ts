export interface IMyInputAutoFill {
  separator: string;
  formatParts: Array<string>;
  enabled: boolean;
}
