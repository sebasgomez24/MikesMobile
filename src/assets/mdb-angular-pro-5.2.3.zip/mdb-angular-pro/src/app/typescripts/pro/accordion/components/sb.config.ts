export const sbConfig = {
    serviceInstance: new Object()
}