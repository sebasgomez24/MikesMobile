import { Component } from '@angular/core';
// import { ToastService } from './typescripts/pro/alerts';

@Component({
  selector: 'mdb-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.css']

})

export class AppComponent {
}
